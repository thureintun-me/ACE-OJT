package studentassingment.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import studentassingment.dao.ClassDAO;
import studentassingment.dao.StudentDAO;

import studentassingment.dto.ClassDTO;
import studentassingment.dto.StudentDTO;


import studentmanagement.model.StudentBean;

/**
 * Servlet implementation class StudentRegisterServlet
 */
@WebServlet("/StudentRegisterServlet")
public class StudentRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentRegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ClassDTO dto = new ClassDTO();
		dto.setClassId("");
		dto.setClassName("");
		ClassDAO dao = new ClassDAO();
		List<ClassDTO> list = new ArrayList<ClassDTO>();
		list = dao.selectClass(dto);
		
		request.getServletContext().setAttribute("classlist", list);
		request.getRequestDispatcher("BUD002.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StudentBean bean = new StudentBean();
		bean.setStudentId(request.getParameter("id"));
		bean.setStudentName(request.getParameter("name"));
		bean.setDay(request.getParameter("day"));
		bean.setMonth(request.getParameter("month"));
		bean.setYear(request.getParameter("year"));
		bean.setStatus(request.getParameter("status"));
		bean.setClassName(request.getParameter("className"));
		
		
		
		if (!bean.getStudentId().equals("") || !bean.getStudentName().equals("") || !bean.getStatus().equals("")
				|| !bean.getClassName().equals("") || !bean.getDay().equals("Day") || !bean.getMonth().equals("Month")
				|| !bean.getYear().equals("Year")) {
			
			StudentDTO dto = new StudentDTO();
			StudentDTO stdto = new StudentDTO();
			stdto.setStudentId(bean.getStudentId());
			
			dto.setStudentId(bean.getStudentId());
			dto.setStudentName(bean.getStudentName());
			dto.setStatus(bean.getStatus());
			dto.setClassName(bean.getClassName());
			dto.setRegisterDate(bean.getYear() + "-" + bean.getMonth() + "-" + bean.getDay());
			StudentDAO dao = new StudentDAO();
			
			List<StudentDTO> list = dao.selectStudent(stdto);
			if (list.size()!=0) 
				request.setAttribute("err", "StudentId has been already exist!");
			else {
				int res = dao.insertStudent(dto);
				if (res > 0)
					request.setAttribute("msg", "Insert successful");
				else
					request.setAttribute("err", "Insert fail");
			}

		
		  } else request.setAttribute("err", "Fields must not be null");
		 
		request.setAttribute("bean", bean);
		request.getRequestDispatcher("BUD002.jsp").forward(request, response);
	}

}
